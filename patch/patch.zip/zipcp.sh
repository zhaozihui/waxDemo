zip patch.zip *
cp patch.zip /Library/WebServer/Documents/
